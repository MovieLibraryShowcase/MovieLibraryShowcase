$(document).ready(function(){
    var html = '';
    var c=0;

    var moviesTitles = [];
    var movies = [];

   var base_url = 'http://dailyrent.com/movieapi/api.php';
                $.ajax({
                type: "POST",
                cache: false,
                async: false,
                url: base_url,
                data: "check="+1,
                success: function( data ) {         
                    data = JSON.parse(data);
                    movies = data;
                    // console.log(data);
                    console.log(JSON.stringify(data));
                   
                    if(data) {

                        for (var key in data) {
                            if(c<=9){                                
                           
                            if (data.hasOwnProperty(key)) {

                                moviesTitles.push(data[key].name);
                                console.log(key + " -> " + data[key].id);
                                html += '<li><div class="content-area"><img src="http://dailyrent.com/movieapi/images/'+data[key].image+'" /><div class="image-desciption"><p class="movie-title">'+data[key].name+'</p><p class="movie-release-date">'+data[key].release_date+'</p><input type="button" id="hideIt" value="Delete" class="delete-it"></div></div></li>';
                            }
                         c++;
                        }
                                
                        }
                    $( '#movieId' ).html( html );   
                        s=1;
                    }else if(data){ 
                        s=0;
                    } 
                    
                   
                }
                    
         });

    $( "#searchMovie" ).keyup(function() {
        var searchText = $( "#searchMovie" ).val();
        var html = '';
        var filterdArr = [];
        console.log(moviesTitles);

        function filterItems(query) {
            return moviesTitles.filter(function(el) {
                return el.toLowerCase().indexOf(query.toLowerCase()) > -1;
            })
        }

        filterdArr = filterItems(searchText);

        for(i = 0; i < movies.length; i++) { 
            for(j = 0; j < filterdArr.length; j++) { 
                if(movies[i].name == filterdArr[j])
                {
                    html += '<li><div class="content-area"><img src="http://dailyrent.com/movieapi/images/'+movies[i].image+'" /><div class="image-desciption"><p class="movie-title">'+movies[i].name+'</p><p class="movie-release-date">'+movies[i].release_date+'</p><input type="button" id="hideIt" value="Delete" class="delete-it"></div></div></li>';
                    
                }
            } 
        }

        setTimeout( function() 
        { 
            console.log(html);

            $( '#movieId' ).html( html );   
        }, 1000);

        



    });
    
    $('.delete-it').click(function(){
        $(this).parents('li').hide();
        
        
    });
/* Add modal */

var modal = document.getElementById('myShowCase');
var btn = document.getElementById("addShowCase");
var span = document.getElementsByClassName("close")[0];
btn.onclick = function() {
    modal.style.display = "block";
}
span.onclick = function() {
    modal.style.display = "none";
}
// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
} 




   

});