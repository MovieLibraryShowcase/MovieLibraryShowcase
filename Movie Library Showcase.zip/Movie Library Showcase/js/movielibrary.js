$(document).ready(function(){
    var html = '';
    var c=0;
   var base_url = 'http://dailyrent.com/movieapi/api.php';
                $.ajax({
                type: "POST",
                cache: false,
                async: false,
                url: base_url,
                data: "check="+1,
                success: function( data ) {         
                    data = JSON.parse(data);
                    //alert(data);
                    console.log(data);
                   
                    if(data) {

                        for (var key in data) {
                            if(c<=9){                                
                           
                            if (data.hasOwnProperty(key)) {
                                console.log(key + " -> " + data[key].id);
                                html += '<li><div class="content-area"><img src="http://dailyrent.com/movieapi/images/'+data[key].image+'" /><div class="image-desciption"><p class="movie-title">'+data[key].name+'</p><p class="movie-release-date">'+data[key].release_date+'</p><input type="button" id="hideIt" value="Delete" class="delete-it"></div></div></li>';
                            }
                         c++;
                        }
                                
                        }
                    $( '#movieId' ).html( html );   
                        s=1;
                    }else if(data){ 
                        s=0;
                    } 
                    
                   
                }
                    
         });
    
    $('.delete-it').click(function(){
        $(this).parents('li').hide();
        
        
    });
/* Add modal */

var modal = document.getElementById('myShowCase');
var btn = document.getElementById("addShowCase");
var span = document.getElementsByClassName("close")[0];
btn.onclick = function() {
    modal.style.display = "block";
}
span.onclick = function() {
    modal.style.display = "none";
}
// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
} 




   

});